const express = require('express');
const bodyParser = require('body-parser');
const sqlite3 = require('sqlite3').verbose();
const path = require('path');
const cors = require('cors');

const app = express();
const PORT = process.env.PORT || 3000;

app.use(cors());
app.use(bodyParser.urlencoded({ extended: false }));
app.use(bodyParser.json());
app.use(express.static(path.join(__dirname, 'public')));

const db = new sqlite3.Database(path.join(__dirname, 'registrations.db'), (err) => {
  if (err) return console.error('DB error', err.message);
  console.log('Conectado a SQLite');
});

const createTableSQL = `
CREATE TABLE IF NOT EXISTS registrations (
  id INTEGER PRIMARY KEY AUTOINCREMENT,
  nombre TEXT NOT NULL,
  documento TEXT NOT NULL,
  email TEXT NOT NULL,
  telefono TEXT,
  programa TEXT,
  fecha_registro TEXT DEFAULT (datetime('now','localtime')),
  comentario TEXT
);
`;

db.run(createTableSQL, (err) => {
  if (err) console.error('Error creando tabla', err.message);
});

app.post('/register', (req, res) => {
  const { nombre, documento, email, telefono, programa, comentario } = req.body;
  if (!nombre || !documento || !email) {
    return res.status(400).json({ error: 'Faltan campos obligatorios (nombre, documento, email).' });
  }

  const insertSQL = `INSERT INTO registrations (nombre, documento, email, telefono, programa, comentario) VALUES (?,?,?,?,?,?)`;
  db.run(insertSQL, [nombre, documento, email, telefono || '', programa || '', comentario || ''], function(err) {
    if (err) {
      console.error('Error insertando', err.message);
      return res.status(500).json({ error: 'Error al guardar el registro.' });
    }
    if (req.headers['accept'] && req.headers['accept'].includes('text/html')) {
      return res.redirect('/success.html');
    }
    res.json({ ok: true, id: this.lastID });
  });
});

app.get('/registrations', (req, res) => {
  const sql = `SELECT id, nombre, documento, email, telefono, programa, fecha_registro, comentario FROM registrations ORDER BY id DESC`;
  db.all(sql, [], (err, rows) => {
    if (err) return res.status(500).json({ error: 'Error consultando registros.' });
    res.json(rows);
  });
});

app.get('/health', (req, res) => res.json({ status: 'ok' }));

app.listen(PORT, () => {
  console.log(`Servidor corriendo en http://localhost:${PORT}`);
});