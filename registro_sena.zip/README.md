# Registro SENA

Formulario de inscripción con Node.js + Express + SQLite.

## Instrucciones

1. Instalar dependencias:
   ```bash
   npm install
   ```

2. Ejecutar localmente:
   ```bash
   npm start
   ```
   Abrir: http://localhost:3000

3. Despliegue en Render:
   - Crear cuenta en https://render.com
   - Subir este proyecto a un repositorio GitHub
   - Crear un nuevo Web Service en Render
   - Configuración:
     - Runtime: Node.js
     - Build Command: npm install
     - Start Command: npm start
   - Render te dará una URL pública como:
     https://registro-sena.onrender.com

4. Endpoints útiles:
   - Formulario: `/`
   - Página de éxito: `/success.html`
   - Ver registros (JSON): `/registrations`
